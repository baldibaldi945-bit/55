package com.imageshrink.app

import android.content.ActivityNotFoundException
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.imageshrink.app.databinding.ActivityMainBinding
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ResultAdapter
    private val executor = Executors.newSingleThreadExecutor()
    private var busy = false

    private val picker =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (!uris.isNullOrEmpty()) process(uris)
        }

    private var pendingUris: List<Uri>? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val uris = pendingUris
            pendingUris = null
            if (granted && uris != null) {
                process(uris)
            } else if (!granted) {
                Toast.makeText(this, R.string.need_storage, Toast.LENGTH_LONG).show()
            }
        }

    /** أندرويد 9 وما دون يحتاج صلاحية التخزين لحفظ الصور في المعرض. */
    private fun ensureStorage(uris: List<Uri>): Boolean {
        if (Build.VERSION.SDK_INT >= 29) return true
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) return true
        pendingUris = uris
        permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ResultAdapter(::openImage, ::shareImage)
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter

        binding.qualityLabel.text = getString(R.string.quality_fmt, binding.qualitySlider.value.toInt())
        binding.qualitySlider.addOnChangeListener { _, value, _ ->
            binding.qualityLabel.text = getString(R.string.quality_fmt, value.toInt())
        }

        binding.pickButton.setOnClickListener {
            if (!busy) picker.launch("image/*")
        }

        if (savedInstanceState == null) handleIncoming(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }

    /** استقبال الصور المُشاركة من تطبيقات أخرى (مشاركة ← ضغط الصور). */
    private fun handleIncoming(intent: Intent?) {
        if (intent == null) return
        val uris: List<Uri> = when (intent.action) {
            Intent.ACTION_SEND ->
                listOfNotNull(IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                    ?.toList() ?: emptyList()
            else -> emptyList()
        }
        if (uris.isNotEmpty()) process(uris)
    }

    private fun currentSettings(): Settings {
        val format = if (binding.chipWebp.isChecked) OutFormat.WEBP else OutFormat.JPEG
        val scale = when {
            binding.chipScale75.isChecked -> 75
            binding.chipScale50.isChecked -> 50
            binding.chipScale25.isChecked -> 25
            else -> 100
        }
        return Settings(binding.qualitySlider.value.toInt(), format, scale)
    }

    private fun process(uris: List<Uri>) {
        if (busy) return
        if (!ensureStorage(uris)) return
        val settings = currentSettings()
        busy = true
        adapter.clear()
        binding.pickButton.isEnabled = false
        binding.progress.visibility = View.VISIBLE
        binding.progress.max = uris.size
        binding.progress.setProgressCompat(0, false)
        binding.summary.visibility = View.VISIBLE
        binding.summary.text = getString(R.string.progress_fmt, 0, uris.size)

        val appContext = applicationContext
        executor.execute {
            var done = 0
            for (uri in uris) {
                val result = Compressor.compress(appContext, uri, settings)
                done++
                val count = done
                runOnUiThread {
                    adapter.add(result)
                    binding.progress.setProgressCompat(count, true)
                    if (count < uris.size) {
                        binding.summary.text = getString(R.string.progress_fmt, count, uris.size)
                    }
                }
            }
            runOnUiThread { finishBatch() }
        }
    }

    private fun finishBatch() {
        busy = false
        binding.pickButton.isEnabled = true
        binding.progress.visibility = View.GONE

        val ok = adapter.items.filter { !it.error && it.originalSize > 0 }
        val okCount = adapter.items.count { !it.error }
        val before = ok.sumOf { it.originalSize }
        val after = ok.sumOf { it.newSize }
        val saved = before - after

        binding.summary.text = if (okCount > 0 && before > 0 && saved > 0) {
            val pct = (saved.toDouble() / before * 100).roundToInt()
            getString(R.string.done_fmt, okCount, Formatter.formatShortFileSize(this, saved), pct)
        } else if (okCount > 0) {
            getString(R.string.done_simple_fmt, okCount)
        } else {
            getString(R.string.all_failed)
        }
    }

    private fun openImage(r: CompressResult) {
        val uri = r.uri ?: return
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            // لا يوجد تطبيق لعرض الصور
        }
    }

    private fun shareImage(r: CompressResult) {
        val uri = r.uri ?: return
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, getString(R.string.share)))
    }
}
