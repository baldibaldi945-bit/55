package com.imageshrink.app

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

enum class OutFormat(val mime: String, val ext: String) {
    JPEG("image/jpeg", "jpg"),
    WEBP("image/webp", "webp")
}

data class Settings(val quality: Int, val format: OutFormat, val scalePercent: Int)

data class CompressResult(
    val name: String,
    val originalSize: Long,
    val newSize: Long,
    val uri: Uri?,
    val thumb: Bitmap?,
    val error: Boolean
)

object Compressor {

    @Suppress("DEPRECATION")
    fun compress(context: Context, source: Uri, s: Settings): CompressResult {
        val resolver = context.contentResolver
        var name = "image"
        var originalSize = -1L

        try {
            resolver.query(
                source,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) originalSize = c.getLong(si)
                }
            }
        } catch (e: Exception) {
            // نكمل بالاسم الافتراضي
        }

        if (originalSize <= 0) {
            originalSize = try {
                resolver.openAssetFileDescriptor(source, "r")?.use { it.length } ?: -1L
            } catch (e: Exception) {
                -1L
            }
        }

        val base = name.substringBeforeLast('.', name)

        return try {
            var bmp = decode(resolver, source, s.scalePercent)

            // JPEG لا يدعم الشفافية: نضع خلفية بيضاء
            if (s.format == OutFormat.JPEG && bmp.hasAlpha()) {
                val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                Canvas(flat).apply {
                    drawColor(Color.WHITE)
                    drawBitmap(bmp, 0f, 0f, null)
                }
                bmp.recycle()
                bmp = flat
            }

            val thumb = makeThumb(bmp)

            val format = when (s.format) {
                OutFormat.JPEG -> Bitmap.CompressFormat.JPEG
                OutFormat.WEBP ->
                    if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
                    else Bitmap.CompressFormat.WEBP
            }

            val stream = ByteArrayOutputStream()
            if (!bmp.compress(format, s.quality, stream)) throw IOException("compress failed")
            bmp.recycle()

            val bytes = stream.toByteArray()
            val uri = save(resolver, "${base}_compressed.${s.format.ext}", s.format.mime, bytes)
            CompressResult(name, originalSize, bytes.size.toLong(), uri, thumb, false)
        } catch (t: Throwable) {
            CompressResult(name, originalSize, 0L, null, null, true)
        }
    }

    /** قراءة الصورة مع التصغير الموفّر للذاكرة وتطبيق اتجاه الصورة (EXIF). يعمل من أندرويد 5. */
    private fun decode(resolver: ContentResolver, uri: Uri, scalePercent: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val w0 = bounds.outWidth
        val h0 = bounds.outHeight
        if (w0 <= 0 || h0 <= 0) throw IOException("unsupported image")

        val targetW = max(1, (w0 * scalePercent / 100.0).roundToInt())
        val targetH = max(1, (h0 * scalePercent / 100.0).roundToInt())

        var sample = 1
        while (w0 / (sample * 2) >= targetW && h0 / (sample * 2) >= targetH) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("decode failed")

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val m = Matrix()
        if (bmp.width != targetW || bmp.height != targetH) {
            m.postScale(targetW.toFloat() / bmp.width, targetH.toFloat() / bmp.height)
        }
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                m.postRotate(90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                m.postRotate(270f)
                m.postScale(-1f, 1f)
            }
        }
        if (!m.isIdentity) {
            val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (out !== bmp) bmp.recycle()
            bmp = out
        }
        return bmp
    }

    private fun makeThumb(bmp: Bitmap): Bitmap {
        val maxSide = 200
        val ratio = maxSide.toFloat() / max(bmp.width, bmp.height)
        if (ratio >= 1f) return bmp.copy(Bitmap.Config.ARGB_8888, false)
        return Bitmap.createScaledBitmap(
            bmp,
            max(1, (bmp.width * ratio).roundToInt()),
            max(1, (bmp.height * ratio).roundToInt()),
            true
        )
    }

    private fun save(resolver: ContentResolver, fileName: String, mime: String, bytes: ByteArray): Uri =
        if (Build.VERSION.SDK_INT >= 29) saveScoped(resolver, fileName, mime, bytes)
        else saveLegacy(resolver, fileName, mime, bytes)

    /** أندرويد 10 وما فوق: بدون أي صلاحية. */
    private fun saveScoped(resolver: ContentResolver, fileName: String, mime: String, bytes: ByteArray): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ImageShrink")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("insert failed")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("no output stream")
            out.use { it.write(bytes) }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    /** أندرويد 9 وما دون: نكتب الملف في Pictures/ImageShrink ثم نسجّله في المعرض. */
    @Suppress("DEPRECATION")
    private fun saveLegacy(resolver: ContentResolver, fileName: String, mime: String, bytes: ByteArray): Uri {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ImageShrink")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("cannot create folder")

        val stem = fileName.substringBeforeLast('.')
        val ext = fileName.substringAfterLast('.')
        var file = File(dir, fileName)
        var n = 1
        while (file.exists()) {
            file = File(dir, "${stem}_$n.$ext")
            n++
        }
        file.outputStream().use { it.write(bytes) }

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.DATA, file.absolutePath)
        }
        return resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("insert failed")
    }
}
